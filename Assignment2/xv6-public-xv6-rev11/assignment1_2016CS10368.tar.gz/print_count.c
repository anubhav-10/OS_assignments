#include "types.h"
#include "user.h"
#include "date.h"
int
main(int argc, char **argv)
{
	print_count();
	exit();
}